package com.example.recyclerviewapp

data class Usuario(
    var nombreCompleto: String,
    var anios: Int,
    var correo: String,
    var clave: String
)
